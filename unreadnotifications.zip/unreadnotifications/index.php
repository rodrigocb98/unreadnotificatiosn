<?php

include ('../../inc/includes.php');
Html::redirect($CFG_GLPI["root_doc"]."/front/helpdesk.public.php");